============
Installation
============

.. note:: Piexif supports Python versions 2.7, 3.5+, PyPy, PyPy3


'easy_install'::

    $ easy_install piexif

or 'pip'::

    $ pip install piexif

or download .zip, extract it. Put 'piexif' directory into your environment.
